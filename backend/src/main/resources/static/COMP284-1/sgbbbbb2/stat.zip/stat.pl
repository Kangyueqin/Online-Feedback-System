#!/usr/bin/perl
use CGI qw(:all);
use LWP::Simple qw(get);
use Data::Dumper;
use XML::Simple;
use utf8;
use Unicode::Normalize;

#Create a new HTML page using CGI 
$new = new CGI;s

#Name of the header of the webpage
print $new->header; 
print $new->start_html('COMP 284: Assignment 1');
print $new->start_form;

#Title of the page
print h1( "COMP 284: Scripting Languages: Assignment 1" );

#Query Text Area is for users to enter an author that they would like to search
print h3("Please enter an author: ");
print $query = $new->textarea(-name=>'query',-default=>'Enter Here',-rows=>6,-columns=>60);	
print $new->br;
print $new->br;

#Max Hits Text Area is for the users to specify how many publictions they want to appear in the results
print h3("Please enter a number for the maximum publications: ");
print $maxHits = $new->textarea(-name=>'maxHits',-default=>'Enter Here',-rows=>6,-columns=>60);
print $new->br;
print $new->br;

#Submit Button is for the user to search the 'URL' using the authors name in 'query text area' and 'maxHits text area'
print $new->submit(-value=>'Submit');
print $new->end_form;
print $new->end_html;


#URL that the user searches from using the 'query' and 'maxHits' text boxes
$URL = ("http://www.dblp.org/search/api/?q=query&h=maxHits&c=4&f=0&format=xml;");
$content = get($URL);

#Error message for maxHits for if the number entered is less than 0
if (!$new->param) {
    print $new->br;
}
elsif (param('maxHits')<=0) {
	print $new->h3('Error: Number required needs to be greater than 0');
}

#Error message for query for if the user submits without entering a name and output if the search is successful
if (!$new->param) {
    print $new->br;
}
elsif (param('query')eq "") {
	print $new->h3('Error: No author entered');	
} else {
   print $content;
}
